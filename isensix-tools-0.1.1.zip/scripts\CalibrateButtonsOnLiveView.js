(async function () {
  const scriptSettings = await chrome.storage.local.get('isensix-script:CalibrateButtonsOnLiveView');
  if (scriptSettings['isensix-script:CalibrateButtonsOnLiveView'] === false) return;
  chrome.runtime.sendMessage({ type: 'SCRIPT_STARTED', name: 'CalibrateButtonsOnLiveView' }).catch(() => {});
// ==UserScript==
// @name         Calibrate Buttons for Live View (ARMS, G2.0, G2.1, G3.0)
// @namespace    https://github.com/LeightonSolo/IsensixScripts
// @version      5.47
// @description  Adds a Calibration button to every sensor on the Isensix Live view page, will work on all ARMS and Guardian servers, Exception buttons WIP
// @author       Leighton Solomon
// @match        https://*/arms2/index.php*
// @match        https://*/arms2/
// @match        https://*/arms/
// @match        https://*/arms/index.php*
// @match        https://*/guardian/index.php*
// @match        https://*/guardian/
// @match        https://*guardian//index.php*
// @downloadURL  https://raw.githubusercontent.com/LeightonSolo/IsensixScripts/main/CalibrateButtonsOnLiveView.js
// @updateURL    https://raw.githubusercontent.com/LeightonSolo/IsensixScripts/main/CalibrateButtonsOnLiveView.js
// @icon         https://www.google.com/s2/favicons?sz=64&domain=isensix.com
// @grant        none
// ==/UserScript==

//  .--.      .--.      .--.      .--.      .--.      .--.      .--.      .--.
//:::::.\::::::::.\::::::::.\  Leighton's Tools \::::::::.\::::::::.\::::::::.\
//'      `--'      `--'      `--'      `--'      `--'      `--'      `--'      `

let arms = 0;
    try { //determine if the system is ARMS or Guardian
        if(document.getElementsByClassName("headline2")[0].innerHTML == "(Advanced Remote Monitoring System)"){
        console.log("ARMS server detected");
        arms = 1;
        }
    }
    catch(err){}

let twoPointZero = 0;
    try { //determine if the system is Guardian 2.1 or 2.0
        if((document.getElementsByClassName("ICO_DISCONNECT")[0].innerHTML == "Sign me off") || (document.querySelector("#guardian-bar-wp-logo > a").title == "Guardian 2.0")){
            console.log("Guardian 2.0 server detected");
            twoPointZero = 1;
        }
    }
    catch(err){}

let threePoint0 = false;
    try {//determine if the server is Guardian 3.0
        if(document.querySelector("#isemainmenu > li:nth-child(1) > a").title == "Guardian 3.0"){
            threePoint0 = true;
            console.log("3.0 Detected");
        }
    }
    catch(err){}

const url = document.URL;
let calUrl = "";
if(arms == 1){
    if(url.includes("ics3")){
        calUrl = url.slice(0, 35) + "admin/index.php?mode=11&id="; //sets to calibation mode for older ARMS servers
    }else{
        calUrl = url.slice(0, 38) + "admin/index.php?mode=11&id="; //sets to calibation mode for older ARMS servers
    }
}
else if(url.slice(33, 38) == "arms/"){
        if(url.includes("ics3")){
               calUrl = url.slice(0, 35) + "calsensor.php?id=";

        }else{
               calUrl = url.slice(0, 38) + "calsensor.php?id=";
        }
}
else if(twoPointZero == 1){ //sets calibration URL for Guardian 2.0
            if(url.includes("ics3")){
                calUrl = url.slice(0, 36) + "calsensor.php?id=";
            }else{
                calUrl = url.slice(0, 39) + "calsensor.php?id=";
            }
}
else if(threePoint0 == 1){ //sets calibration URL for Guardian 3.0
    if(url.includes("ics3")){
            calUrl = url.slice(0, 39) + "calibration/calsensor.php?id=";
    }else{
        calUrl = url.slice(0, 42) + "calibration/calsensor.php?id=";
    }
}
else{ //sets calibration URL for Guardian 2.1
        if(url.includes("ics3")){
            calUrl = url.slice(0, 36) + "calibration/calsensor.php?id=";
        }else{
            calUrl = url.slice(0, 39) + "calibration/calsensor.php?id=";
        }
}

function openCalUrl(id, butt){
   window.open(calUrl + id);
    butt.style.backgroundColor = '#00e1ff'; //set color of button (to locate easier on live view)
}

function getSensorId(element) {
    const source = element.getAttribute('onclick') || element.getAttribute('href') || '';
    const matches = source.match(/\d{3,}/g);
    return matches ? matches[matches.length - 1] : null;
}

(function() {
    'use strict';

    if(arms == 0){//if system is detected to be guardian
        if(threePoint0){ //G3.0
            //let sensorList = document.getElementsByClassName("slnk"); //gets list of all sensors on the live view page
            let sensorList = [
              ...document.getElementsByClassName("slnk"),
              ...document.getElementsByClassName("slnk-title")
            ];

            const sensorList2 = document.getElementsByClassName("lvhead");

            for (let i = 0; i < sensorList.length; i++) {
                const id = getSensorId(sensorList[i]);
                if (!id) continue;
                //console.log(id);//gets the ID of the sensor from the html
                let butt=document.createElement("button");

                butt.textContent="\u25c9";
                butt.title = "Calibrate";


                butt.addEventListener("click", () => openCalUrl(id, butt));

                //sensorList2[i].appendChild(butt);

                let cell = document.createElement("td");
                // Get first row of table
                /*let row = sensorList2[i].rows[0];
                // Create new row if row doesn't exist
                if(!row) {
                    row = document.createElement("row");
                    sensorList2[i].appendChild(row);
                }*/
                                    //sensorList2[i].appendChild(butt);
                                                    sensorList[i].parentElement.parentElement.appendChild(butt);


                // Add button to sensor table cell
                //cell.appendChild(butt);
                //row.prepend(cell);
            }

        }
        else{ //G2.1 and G2.0

            let sensorList = document.getElementsByClassName("slnk poplink"); //gets list of all sensors on the live view page

            if (sensorList.length === 0){
                sensorList = document.getElementsByClassName("slnk "); //handle weird 2.0 servers that have a different class for sensor name
            }
            const sensorList2 = document.getElementsByClassName("mon");

            for (let i = 0; i < sensorList.length; i++) {
                const id = getSensorId(sensorList[i]);
                if (!id) continue;
                let butt=document.createElement("button");

                butt.textContent="\u25c9";
                butt.title = "Calibrate";

                butt.addEventListener("click", () => openCalUrl(id, butt));

                //sensorList2[i].appendChild(butt);

                let cell = document.createElement("td");
                // Get first row of table
                let row = sensorList2[i].rows[0];
                // Create new row if row doesn't exist
                if(!row) {
                    row = document.createElement("row");
                    sensorList2[i].appendChild(row);
                }
                // Add button to sensor table cell
                cell.appendChild(butt);
                row.prepend(cell);
            }
        }
    }
    else if(arms == 1){ //if system is detected to be ARMS

        const sensorList = document.getElementsByClassName("noul"); //gets list of all sensors on the live view page

        for (let i = 0; i < sensorList.length; i++) {
            const href = sensorList[i].getAttribute("href") || "";
            if(href.slice(0, 12) == "sensordetail"){
                const id = getSensorId(sensorList[i]);
                if (!id) continue;
                let butt=document.createElement("button");

                butt.textContent="\u25c9";
                butt.title = "Calibrate";


                butt.addEventListener("click", () => openCalUrl(id, butt));

                sensorList[i].parentElement.parentElement.prepend(butt); //adds calibrate button to parent table

            }
        }
    }

})();

})();
