(async function () {
  const scriptSettings = await chrome.storage.local.get('isensix-script:CalibratedCheckmarks');
  if (scriptSettings['isensix-script:CalibratedCheckmarks'] === false) return;
  chrome.runtime.sendMessage({ type: 'SCRIPT_STARTED', name: 'CalibratedCheckmarks' }).catch(() => {});
// ==UserScript==
// @name         Calibrated Checkmarks and Autocollapse Zones (ARMS, G2.0, G2.1, G3.0)
// @namespace    https://github.com/LeightonSolo/IsensixScripts
// @version      5.13
// @description  Shows which sensors have been calibrated on the live view using dashboard state with local fallback. Zones can be automatically collapsed when calibrated.
// @match        https://*/arms2/index.php*
// @match        https://*/arms2/
// @match        https://*/arms/
// @match        https://*/arms/index.php*
// @match        https://*/arms/calreport.php?*
// @match        https://*/arms2/calibration/calreport.php*
// @match        https://*/guardian/calibration/calreport.php*
// @match        https://*/guardian/calibration//calreport.php*
// @match        https://*/guardian/iserep1.php*
// @match        https://*/guardian/index.php*
// @match        https://*/guardian/
// @match        https://*/arms2/calibration//calreport.php*
// @match        https://*/arms2/calsetup.php*
// @match        https://*/arms/calsetup.php*
// @match        https://*/arms2/iserep1.php*
// @match        https://*/arms/iserep1.php*
// @match        https://*/arms/debug/debug_query.php*
// @downloadURL  https://raw.githubusercontent.com/LeightonSolo/IsensixScripts/main/CalibratedCheckmarks.js
// @updateURL    https://raw.githubusercontent.com/LeightonSolo/IsensixScripts/main/CalibratedCheckmarks.js
// @icon         https://www.google.com/s2/favicons?sz=64&domain=isensix.com
// @grant GM_getValue
// @grant GM.setValue
// @grant GM_xmlhttpRequest
// @connect flat-tree-380f.leightonsolo.workers.dev
// ==/UserScript==

//  .--.      .--.      .--.      .--.      .--.      .--.      .--.      .--.
//:::::.\::::::::.\::::::::.\  Leighton's Tools \::::::::.\::::::::.\::::::::.\
//'      `--'      `--'      `--'      `--'      `--'      `--'      `--'      `

const url = document.URL;

let arms = 0;

if(url.includes("debug_query.php")){
   arms = 1;
   console.log("ARMS detected");
}


let threePoint0 = false;
    try {//determine if the server is Guardian 3.0
        if(document.querySelector("#isemainmenu > li:nth-child(1) > a").title == "Guardian 3.0"){
            threePoint0 = true;
            console.log("3.0 Detected");
        }
    }
    catch(err){}

    try { //determine if the system is ARMS or Guardian
        if((document.getElementsByClassName("headline2")[0].innerHTML == "(Advanced Remote Monitoring System)")){
            arms = 1;
            console.log("ARMS detected");
        }
    }
    catch(err){}

let twoPointZero = 0;
    try { //determine if the system is Guardian 2.1 or 2.0
        if(document.getElementsByClassName("ICO_DISCONNECT")[0].innerHTML == "Sign me off"){
            twoPointZero = 1;
            console.log("Guardian 2.0 Detected");
        }
        if(document.querySelector("#guardian-bar-wp-logo > a").title == "Guardian 2.0"){
            twoPointZero = 1;
            console.log("2.0 Detected");
        }
    }
    catch(err){}



let toggleKey = `toggleState_${window.location.host}`;

function getSensorId(element) {
    const onclick = element.getAttribute('onclick') || '';
    const onclickId = onclick.match(/pop_sd\(\s*(\d+)\s*\)/i)?.[1];
    if (onclickId) return onclickId;

    const href = element.getAttribute('href') || '';
    return href.match(/[?&]id=(\d+)(?:[&#]|$)/i)?.[1] || null;
}

const WORKER_URL = 'https://flat-tree-380f.leightonsolo.workers.dev';
const API_KEY = 'U87iy7VynFYLJUDnfUYBJHnRKbRiQO3Z';
const ROLLING_DAYS_KEY = 'calibrationWindowDays';
const DEFAULT_ROLLING_DAYS = 7;

async function getRollingDays() {
    const saved = Number(await GM.getValue(ROLLING_DAYS_KEY, DEFAULT_ROLLING_DAYS));
    return Number.isFinite(saved) ? Math.min(Math.max(Math.round(saved), 1), 60) : DEFAULT_ROLLING_DAYS;
}

function workerRequest(method, path) {
    return new Promise((resolve, reject) => {
        GM_xmlhttpRequest({
            method,
            url: `${WORKER_URL}${path}`,
            headers: { 'X-Api-Key': API_KEY },
            onload: response => response.status >= 200 && response.status < 300
                ? resolve(response.responseText ? JSON.parse(response.responseText) : {})
                : reject(new Error(`Worker returned ${response.status}`)),
            onerror: () => reject(new Error('Worker request failed')),
        });
    });
}

async function loadDashboardCalibrationState(server) {
    if (!server) return null;
    try {
        const payload = await workerRequest('GET', `/live-view/state?server=${encodeURIComponent(server)}`);
        const state = new Map();
        for (const sensor of payload.sensors || []) state.set(String(sensor.sensor_id), sensor);
        return state;
    } catch (error) {
        console.warn('[Isensix Tools] Dashboard calibration state unavailable; using local fallback.', error);
        return null;
    }
}

function isWithinRollingWindow(calibratedAt, rollingDays) {
    if (!calibratedAt) return false;
    const parsed = typeof calibratedAt === 'number'
        ? calibratedAt
        : new Date(String(calibratedAt).replace(' ', 'T')).getTime();
    if (!Number.isFinite(parsed)) return false;
    return Date.now() - parsed <= rollingDays * 24 * 60 * 60 * 1000;
}

async function isCalibratedSensor(sensorId, storedName, dashboardState, rollingDays) {
    if (dashboardState) {
        return isWithinRollingWindow(dashboardState.get(String(sensorId))?.calibrated_at, rollingDays);
    }

    const stored = await GM.getValue(storedName, false);
    return stored === true || isWithinRollingWindow(stored, rollingDays);
}

async function addCalibrationWindowControl(container, rollingDays) {
    if (!container) return;
    const wrapper = document.createElement('span');
    wrapper.style.cssText = 'display:inline-flex;align-items:center;gap:5px;margin:8px 8px 0 0;';

    const label = document.createElement('label');
    label.textContent = 'Calibration window (days):';
    label.title = 'The number of days in the past to check if a sensor is calibrated.';
    const input = document.createElement('input');
    input.type = 'number';
    input.min = '1';
    input.max = '60';
    input.step = '1';
    input.value = String(rollingDays);
    input.style.width = '52px';

    const save = document.createElement('button');
    save.textContent = 'Save';
    save.addEventListener('click', async () => {
        const value = Math.min(Math.max(Math.round(Number(input.value) || DEFAULT_ROLLING_DAYS), 1), 60);
        input.value = String(value);
        await GM.setValue(ROLLING_DAYS_KEY, value);
        save.textContent = 'Saved';
        setTimeout(() => location.reload(), 300);
    });

    wrapper.append(label, input, save);
    container.appendChild(wrapper);
}

async function toggleZones(){
    const savedState = localStorage.getItem(toggleKey);
    //let toggleZones = await GM.getValue("toggleZones");
    //if(toggleZones){
    if(savedState === 'ON'){
        if(arms == 1){
            //window.location="/arms/index.php?x=&zva=1";
            location.reload();
            console.log("Showing all zones");
        }
        else if(twoPointZero == 1){

            var links = document.querySelectorAll('a');

            //Iterate over  links to find the one with the text "Show All Sensors"
            links.forEach(function(link) {
                if (link.textContent.trim() === "Show All Sensors") {
                    link.click();

                    // Wait a bit and then force the browser to go to the URL to override redirection
                    setTimeout(function() {
                        window.location.href = link.href;
                    }, 100); // 100 ms delay before overriding
                }
            });

            //window.location="/arms/index.php?vmode=2;zva=1";
            console.log("Showing all zones");

        }
            else{
                location.reload();
        }
        localStorage.setItem(toggleKey, 'OFF');

    }
    else{
        localStorage.setItem(toggleKey, 'ON');
            location.reload();

    }
}

    const currentDate = new Date();

(async function() {
    'use strict';


    //CLEANUP CALIBRATION DATA EVERY 10 MONTHS
    // Initialize the current date

    // Load the last cleanup timestamp
    const lastCleanup = await GM.getValue("lastCleanup", 0);

    // Check if 10 months have passed since the last cleanup
    const TEN_MONTHS_MS = 10 * 30 * 24 * 60 * 60 * 1000; // Approximation: 10 months in milliseconds
    if (currentDate.getTime() - lastCleanup >= TEN_MONTHS_MS) {
        console.log("10 months have passed. Clearing stored calibration values...");

        // Get all stored keys and clear them
        const keys = await GM.listValues();
        for (const key of keys) {
            if (key === ROLLING_DAYS_KEY) continue;
            await GM.deleteValue(key);
        }

        // Update the last cleanup timestamp
        await GM.setValue("lastCleanup", currentDate.getTime());
        console.log("All stored values cleared and cleanup timestamp updated.");
    }
    // ========================================================================

    var inputString = document.URL;
            var regex = /:(\d{4})/;
            var match = inputString.match(regex);

            if (match) {
                var server = match[1];
                server = server.slice(1); //will get the three digit server ID
            }

    const rollingDays = await getRollingDays();
    const isLiveView = /\/(?:arms2|arms|guardian)(?:\/+index\.php)?\/?$/i.test(window.location.pathname);
    const dashboardState = isLiveView ? await loadDashboardCalibrationState(server) : null;



    //================================================ ARMS ===================================================================================================
    if(arms == 1){ //ARMS

        if((document.URL).includes("/arms/calreport.php")){

            const table = document.getElementsByTagName("table")[6];
            let d = table.getElementsByTagName("tr")[14];
            let check = d.getElementsByTagName("td")[0];
            let sensorId = "";


            for(let j = 0; j < table.getElementsByTagName("tr").length; j++){
                try {
                    d = table.getElementsByTagName("tr")[j];
                    check = d.getElementsByTagName("td")[0];
                    if(check.innerHTML == "Sensor ID"){
                        sensorId = d.getElementsByTagName("td")[1].innerHTML;
                    }
                }
                catch(err){}
            }

            const report = document.getElementsByClassName("report")[0];
            const d2 = report.getElementsByTagName("tr")[4];
            const lastCal = d2.getElementsByTagName("td")[0];

            const parsed = Date.parse(lastCal.innerHTML) / 1000; //get a unix timestamp of the last calibration date (javascript works with milliseconds since epoch)

            if(((Date.now() / 1000) - parsed) < rollingDays * 86400){ //determine if sensor is inside the rolling calibration window
                //alert("past week");
                let storeName = server + "," + sensorId; //store the sensor as calibrated in the format of SERVER,SENSORID
                GM.setValue(storeName, parsed * 1000);
                console.log("Storing sensor as calibrated: " + storeName);
            }
        }
        else if((document.URL).includes("/debug_query.php")){ //store calibration data from ARMS Debug Query

            let table = document.getElementsByTagName("table")[0];
            if (!table) return;
            let sensorId = "";

            // Get all the rows of the table
            let tableRows = table.querySelectorAll('tr');
            //tableRows.forEach(function(item, index) {
            //console.log('Item ' + index + ':', item);
            //});
            for (let i = 1; i < tableRows.length; i++) {
                // Get the date from the 11th td
                let dateSpan = tableRows[i].querySelector('td:nth-child(11)');

                const parsed = Date.parse(dateSpan.innerHTML) / 1000; //get a unix timestamp of the last calibration date (javascript works with milliseconds since epoch)

                if(((Date.now() / 1000) - parsed) < rollingDays * 86400){ //determine if sensor is inside the rolling calibration window
                    let sensorId = tableRows[i].querySelector('td:nth-child(1)').textContent;
                    let storeName = server + "," + sensorId; //store the sensor as calibrated in the format of SERVER,SENSORID
                    GM.setValue(storeName, parsed * 1000);
                    console.log("Storing sensor as calibrated: " + storeName);
                }
            }
        }
        else{ //live view on ARMS

            const sensorList = document.querySelectorAll('a.noul[href*="sensordetail.php"]'); //gets list of all sensors on the live view page
            const zoneHideButton = document.getElementsByClassName("zview")[0];

            let butt=document.createElement("button");
            let toggleZoneState = localStorage.getItem(toggleKey);
            if(toggleZoneState == "ON"){
                butt.innerHTML="Show All Zones";
                butt.style.fontWeight = "bold";
                butt.style.backgroundColor = '#ff512b';
            }
            else{
                butt.innerHTML="Only Show Non Calibrated Zones";
            }
            butt.addEventListener("click", () => toggleZones());

            zoneHideButton.appendChild(butt);

            for (let i = 0; i < sensorList.length; i++) {
                const href = sensorList[i].getAttribute("href") || "";
                if (/(?:^|\/)sensordetail\.php(?:[?#]|$)/i.test(href)) {
                    let id = getSensorId(sensorList[i]);
                    if (!id) continue;
                    let storedName = server + "," + id;
                    let check = await isCalibratedSensor(id, storedName, dashboardState, rollingDays);

                    if(check){
                        let checkMark = document.createTextNode(' \u2713 Calibrated');
                        sensorList[i].parentElement.parentElement.style.fontSize = '11px';
                        sensorList[i].parentElement.parentElement.style.fontWeight = 'bold';
                        sensorList[i].parentElement.parentElement.prepend(checkMark); //adds checkmark to parent table
                        sensorList[i].parentElement.parentElement.parentElement.parentElement.parentElement.parentElement.parentElement.style.opacity = 0.4;
                        //alert("adding check");
                       }
                }
            }
            let zoneTables = document.getElementsByClassName("tbord");
            zoneTables = Array.from(zoneTables).filter(element => element.tagName === "TABLE");

            for(let i = 0; i < zoneTables.length; i++){

                //Count sensors in zone by getting count of signal images
                let images = zoneTables[i].querySelectorAll('img');

                // Filter the images to match the specific source
                let filteredImages = Array.from(images).filter(img => img.src.includes('signal'));

                let zoneCount = 0;

                try{zoneCount = filteredImages.length;}
                catch(err){}

                let calibratedCount = 0;
                //alert(zoneTables.length) //28
                const table = zoneTables[i];

                // Get the innerText of the table (text content without HTML tags)
                const tableText = table.innerText;
                // Count occurrences of calibrated
                const occurrences = tableText.split("✓").length - 1;

                // Add the occurrences to the total count
                calibratedCount += occurrences;
                //console.log("Zone: " + i);
                //console.log("Calibrated: " + calibratedCount);


                //try{
                    const zoneName = zoneTables[i].querySelector("tbody > tr:nth-child(1) > td > table > tbody > tr > td.zonename > a.zonelink").textContent;
                    let zoneTitle = document.createTextNode(zoneName + ' - ' + zoneCount + ' Active, ' + calibratedCount + ' Calibrated. ' + (zoneCount - calibratedCount) + ' left.');

                    zoneTables[i].style = "white-space:nowrap";
                    zoneTables[i].style.fontSize = '14px';

                    if((calibratedCount == zoneCount) && (toggleZoneState == "ON")){
                        zoneTables[i].style.backgroundColor = '#9eff7f';
                        zoneTitle = document.createTextNode(zoneName + ' - ' + zoneCount + ' Active, ' + calibratedCount + ' Calibrated.');
                    //close zone
                    /*const firstLink = table.querySelector('a')[1];
                    if (firstLink) {
                        firstLink.click();
                    }*/
                        zoneTables[i].children[0].style = "display:none"; //hide not remove, cause ARMS freaks out otherwise
                    }
                    if(zoneCount == 0){
                        zoneTitle = document.createTextNode(zoneName + ' - 0 Active, or Hidden');
                    }
                    zoneTables[i].prepend(zoneTitle); //adds zone count and calibrated to zone title

                //}catch(err){};

            }
            //create button to allow manually deleting all stored sensor data if needed  ======
            let deleteButt=document.createElement("button");
            deleteButt.innerHTML="Delete Stored Calibration Data from Leighton's Tools";
            deleteButt.addEventListener("click", () => deleteStoredData());
            document.querySelector("body > hr").appendChild(deleteButt);
            await addCalibrationWindowControl(document.querySelector("body > hr")?.parentElement || document.body, rollingDays);
            //=============================================================================
        }
    }
    //================================================ GUARDIAN 2.0 ================================================================================================
    else if(twoPointZero == 1){

        if((document.URL).includes("/calsetup.php")){

            const table = document.getElementsByTagName("table")[0];
            let sensorId = "";

            // Get all the rows of the table
            let tableRows = table.querySelectorAll('tr');
            //tableRows.forEach(function(item, index) {
            //console.log('Item ' + index + ':', item);
            //});
            for (let i = 1; i < tableRows.length; i++) {
                // Get the date from the second span tag
                let dateSpan = tableRows[i].querySelector('td span:nth-child(2)');

                const parsed = Date.parse(dateSpan.innerHTML) / 1000; //get a unix timestamp of the last calibration date (javascript works with milliseconds since epoch)

                if(((Date.now() / 1000) - parsed) < rollingDays * 86400){ //determine if sensor is inside the rolling calibration window
                //alert("past week");
                    let sensorId = tableRows[i].querySelector('td:nth-child(1)').textContent;
                    let storeName = server + "," + sensorId; //store the sensor as calibrated in the format of SERVER,SENSORID
                    GM.setValue(storeName, parsed * 1000);
                    console.log("Storing sensor as calibrated: " + storeName);
                }
            }
        }
        else if((document.URL).includes("/iserep1.php")){ //collect calibrated data from isensix calibration summary

            const table = document.getElementsByClassName("arms p100")[0];
            let sensorId = "";

            // Get all the rows of the table
            let tableRows = table.querySelectorAll('tr');

            //tableRows.forEach(function(item, index) {
            //    console.log('Item ' + index + ':', item);
            //});
            for (let i = 1; i < (tableRows.length); i++) {
                // Get the date from the table row
                let dateSpan = tableRows[i].querySelector('tr td:nth-child(11)');

                const parsed = Date.parse(dateSpan.innerHTML) / 1000; //get a unix timestamp of the last calibration date (javascript works with milliseconds since epoch)

                if(((Date.now() / 1000) - parsed) < rollingDays * 86400){ //determine if sensor is inside the rolling calibration window
                //alert("past week");
                    let sensorId = tableRows[i].querySelector('tr td:nth-child(1)').textContent.trim();
                    let storeName = server + "," + sensorId; //store the sensor as calibrated in the format of SERVER,SENSORID
                    GM.setValue(storeName, parsed * 1000);
                    console.log("Storing sensor as calibrated: " + storeName);
                }
            }
        }
        else{

            const sensorList = document.getElementsByClassName("slnk poplink"); //gets list of all sensors on the live view page
            const zoneHideButton = document.getElementsByClassName("atoolbar")[0];


            let butt = document.createElement("button");
            butt.className = "ui-button-text";
            butt.style.marginLeft = "12px";

            let toggleZoneState = localStorage.getItem(toggleKey);

            if (toggleZoneState == "ON") {
                butt.innerHTML = "Show All Zones";
                butt.style.fontWeight = "bold";
                butt.style.color = "#7C0A02";

            } else {
                butt.innerHTML = "Show Only Non Calibrated Zones";
            }

            butt.addEventListener("click", () => toggleZones());

            zoneHideButton.appendChild(butt);


            for (let i = 0; i < sensorList.length; i++) {
                let id = getSensorId(sensorList[i]);
                if (!id) continue;

                let storedName = server + "," + id;
                let check = await isCalibratedSensor(id, storedName, dashboardState, rollingDays);

                if(check){
                    let checkMark = document.createTextNode(' \u2713 Calibrated');
                    sensorList[i].parentElement.parentElement.style.fontSize = '11px';
                    sensorList[i].parentElement.parentElement.style.fontWeight = 'bold';
                    sensorList[i].parentElement.parentElement.prepend(checkMark);
                    sensorList[i].parentElement.parentElement.parentElement.parentElement.parentElement.parentElement.style.opacity = 0.4;
                    //alert("adding check");
                }
            }

            // Show counts in zones for 2.0 ======================================
            const zoneTables = document.getElementsByClassName("zone p100");
            const ajaxBodyElement = document.querySelector('ajaxbody');
            if (ajaxBodyElement) {
               ajaxBodyElement.style.lineHeight = '0.6'; //shrink <br> spaces between zones
            }

            for(let i = 0; i < zoneTables.length; i++){

                //alert(zoneTable.innerHTML);
                 let images = zoneTables[i].querySelectorAll('img');

                // Filter the images to match the specific source
                let filteredImages = Array.from(images).filter(img => img.src.includes('signal'));

                let zoneCount = 0;

                try{zoneCount = filteredImages.length;}
                catch(err){}

                let calibratedCount = 0;
                //alert(zoneTables.length) //28
                const table = zoneTables[i];

                // Get the innerText of the table (text content without HTML tags)
                const tableText = table.innerText;
                // Count occurrences of calibrated
                const occurrences = tableText.split("✓").length - 1;

                // Add the occurrences to the total count
                calibratedCount += occurrences;
                //console.log("Zone: " + i);
                //console.log("Calibrated: " + calibratedCount);
                //const zoneName = document.querySelector("tbody > tr:nth-child(1) > td > table > tbody > tr > td.zonename > a.zonelink");
                const zoneName = zoneTables[i].querySelector("tbody > tr:nth-child(1) > td > table > tbody > tr > td.zonename > a.zonelink").textContent;

                const title = zoneTables[i].querySelector(".zonename a:last-of-type");
                let count = document.createElement("span");
                    count.textContent = ` - ${calibratedCount}/${zoneCount} Calibrated`;
                    count.style.fontWeight = "bold";

                let zoneTitle = document.createTextNode(zoneName + ' - ' + zoneCount + ' Sensors, ' + calibratedCount + ' Calibrated. ' + (zoneCount - calibratedCount) + ' left.');

                zoneTables[i].style = "white-space:nowrap";
                zoneTables[i].style.fontSize = '14px';

                if((calibratedCount == zoneCount)){
                    title.parentElement.parentElement.parentElement.parentElement.style.backgroundColor = '#9eff7f';
                    //zoneTables[i].style.backgroundColor = '#9eff7f';
                    zoneTitle = document.createTextNode(zoneName + ' - ' + zoneCount + ' Sensors, ' + calibratedCount + ' Calibrated.');
                    if(toggleZoneState == "ON"){
                        //zoneTables[i].children[0].remove();
                        const tbody = zoneTables[i].querySelector("tbody");
                            if (tbody) {
                                Array.from(tbody.children).slice(1).forEach(row => {
                                    row.style.display = "none";
                                });
                            }
                    }
                }
                if(zoneCount == 0){
                     zoneTitle = document.createTextNode(zoneName + ' - 0 Active, or Hidden');
                }
                title.insertAdjacentElement("afterend", count);

                //zoneTables[i].prepend(zoneTitle); //adds zone count and calibrated to zone title
            }
            //create button to allow manually deleting all stored sensor data if needed  ======
            let deleteButt=document.createElement("button");
            deleteButt.innerHTML="Delete Stored Calibration Data from Leighton's Tools";
            deleteButt.addEventListener("click", () => deleteStoredData());
            document.querySelector("#body").appendChild(deleteButt);
            await addCalibrationWindowControl(document.querySelector("#body"), rollingDays);
            //=============================================================================
        }
    }
    //================================================ GUARDIAN 2.1 and 3.0 ================================================================================================
    else if(twoPointZero == 0){

        if((document.URL).includes("/calreport.php")){ //store calibration data from calibration page - WORKS ON 3.0

            const table = document.getElementsByTagName("table")[0];
            let sensorId = "";

            // Get all the rows of the table
            let tableRows = table.querySelectorAll('tr');

            //tableRows.forEach(function(item, index) {
            //    console.log('Item ' + index + ':', item);
            //});
            //console.log(tableRows.length);
            for (let i = 1; i < (tableRows.length); i++) { //go through all table rows
                // Get the date from the table row
                let dateSpan = tableRows[i].querySelector('tr td:nth-child(7)').innerHTML;
                if(threePoint0){
                    dateSpan = tableRows[i].querySelector("td:nth-child(7) > span:nth-child(1)").innerHTML; //.split(" ")[0];
                }
                //console.log(dateSpan);

                const parsed = Date.parse(dateSpan) / 1000; //get a unix timestamp of the last calibration date (javascript works with milliseconds since epoch)
                //console.log(parsed);

                if(((Date.now() / 1000) - parsed) < rollingDays * 86400){ //determine if sensor is inside the rolling calibration window
                //alert("past week");
                    let sensorId = tableRows[i].querySelector('tr td:nth-child(1)').textContent.trim();
                    if(threePoint0){
                        try{
                        sensorId = tableRows[i].querySelector('tr td:nth-child(3)').textContent.trim().match(/(\d+)/)[0];
                            //console.log(sensorId);

                        }
                        catch(err){}
                    }
                    let storeName = server + "," + sensorId; //store the sensor as calibrated in the format of SERVER,SENSORID
                    GM.setValue(storeName, parsed * 1000);
                    console.log("Storing sensor as calibrated: " + storeName);
                }
            }
        }
        else if((document.URL).includes("/iserep1.php")){ //collect calibrated data from isensix calibration summary

            const table = document.getElementsByClassName("arms p100")[0];
            let sensorId = "";

            // Get all the rows of the table
            let tableRows = table.querySelectorAll('tr');

            //tableRows.forEach(function(item, index) {
            //    console.log('Item ' + index + ':', item);
            //});
            for (let i = 1; i < (tableRows.length); i++) {
                // Get the date from the table row
                let dateSpan = tableRows[i].querySelector('tr td:nth-child(11)');

                const parsed = Date.parse(dateSpan.innerHTML) / 1000; //get a unix timestamp of the last calibration date (javascript works with milliseconds since epoch)

                if(((Date.now() / 1000) - parsed) < rollingDays * 86400){ //determine if sensor is inside the rolling calibration window
                //alert("past week");
                    let sensorId = tableRows[i].querySelector('tr td:nth-child(1)').textContent.trim();
                    let storeName = server + "," + sensorId; //store the sensor as calibrated in the format of SERVER,SENSORID
                    GM.setValue(storeName, parsed * 1000);
                    console.log("Storing sensor as calibrated: " + storeName);
                }
            }
        }
        else{
            let sensorList = document.getElementsByClassName("slnk poplink"); //gets list of all sensors on the live view page
            if(threePoint0){
                //sensorList = document.getElementsByClassName("slnk");
                 sensorList = [
              ...document.getElementsByClassName("slnk"),
              ...document.getElementsByClassName("slnk-title")
            ];
            }
            //console.log(sensorList);

            let zoneHideButton = document.getElementsByClassName("noprint flex_nav")[0];
            if(!zoneHideButton){
                zoneHideButton = document.querySelector("#body > div > form"); //catch for weird G2.0 servers
            }
            if(threePoint0){ zoneHideButton = document.getElementsByClassName("noprint flex_nav")[1]; }

           
            let butt = document.createElement("button");
            butt.className = "ui-button small ui-corner-all ui-widget";
            butt.style.marginLeft = "12px";

            let toggleZoneState = localStorage.getItem(toggleKey);

            if (toggleZoneState == "ON") {
                butt.innerHTML = "Show All Zones";
                butt.style.fontWeight = "bold";
                butt.style.color = "#7C0A02";

            } else {
                butt.innerHTML = "Show Only Non Calibrated Zones";
            }

            butt.addEventListener("click", () => toggleZones());

            //if(!threePoint0){zoneHideButton.appendChild(butt);}
            if(zoneHideButton){
                zoneHideButton.appendChild(butt);
            }

            for (let i = 0; i < sensorList.length; i++) {
                let id = getSensorId(sensorList[i]);
                if (!id) continue;

                let storedName = server + "," + id;
                //console.log(storedName);
                let check = await isCalibratedSensor(id, storedName, dashboardState, rollingDays);
                //console.log(check);

                if(check){
                    let checkMark = document.createTextNode(' \u2713 Calibrated');
                    sensorList[i].parentElement.parentElement.style.fontSize = '11px';
                    sensorList[i].parentElement.parentElement.style.fontWeight = 'bold';
                    if(threePoint0){
                        sensorList[i].parentElement.parentElement.prepend(checkMark);
                        sensorList[i].parentElement.parentElement.parentElement.parentElement.parentElement.style.opacity = 0.35;
                    }else{
                        sensorList[i].parentElement.parentElement.prepend(checkMark);
                        sensorList[i].parentElement.parentElement.parentElement.parentElement.parentElement.parentElement.style.opacity = 0.35;
                    }

                }
            }

            //create button to allow manually deleting all stored sensor data if needed  ======
            let deleteButt=document.createElement("button");
            deleteButt.innerHTML="Delete Stored Calibration Data from Leighton's Tools";
            deleteButt.addEventListener("click", () => deleteStoredData());
            deleteButt.title = "This will make Leighton's Tools scripts forget which sensors have been calibrated across all servers. No data on the servers themselves will be affected.";
            document.querySelector("#body").appendChild(deleteButt);
            await addCalibrationWindowControl(document.querySelector("#body"), rollingDays);
            //=============================================================================



            //if(threePoint0){zoneTables = document.getElementsByClassName("ui-widget-header zonetop apad");}

            const ajaxBodyElement = document.querySelector('.ajaxbody');
            if (ajaxBodyElement) {
               ajaxBodyElement.style.lineHeight = '0.7'; //shrink <br> spaces between zones
            }

            if(threePoint0){ //show calibrated counts for each zone on 3.0

                    document.querySelectorAll(".zonetop").forEach(zone => {
                        let total = 0;
                        let calibrated = 0;
                        let sensors = [];

                        // Walk through everything after this zone until the next zone
                        let el = zone.nextElementSibling;
                        let zoneContents = [];

                        while (el && !el.classList.contains("zonetop")) {
                             zoneContents.push(el);

                            // Ignore system sensors/checkpoints
                            if (
                                el.classList.contains("senbox") &&
                                !el.classList.contains("issystem") &&
                                !el.classList.contains("tdis")
                            ) {
                                sensors.push(el);
                                total++;

                                const head = el.querySelector(".lvhead");
                                if (el.querySelector(".lvhead")?.textContent.includes("✓")) {
                                    calibrated++;
                                }

                            }

                            el = el.nextElementSibling;
                        }

                        // Add the counts to the zone header
                        let badge = document.createElement("span");
                        badge.style.marginLeft = "10px";
                        badge.style.fontWeight = "bold";
                        badge.textContent = `${calibrated}/${total} Calibrated`;


                        if (total > 0 && calibrated === total) {

                            zone.style.background = "#88E788";
                            badge.textContent = `${calibrated}/${total} Calibrated \u2705`;
                            if(toggleZoneState == "ON"){
                                zoneContents.forEach(el => el.style.display = "none");
                            }
                        }
                    if(total == 0){
                        badge.textContent = ` - 0 Active, or Hidden`;
                    }
                    zone.appendChild(badge);
                });

            }
            else{ //=================== 2.1 ==========================

                let zoneTables = document.getElementsByClassName("zone p100");

                for(let i = 0; i < zoneTables.length; i++){


                    //alert(zoneTable.innerHTML);
                    let images = zoneTables[i].querySelectorAll('img');

                    // Filter the images to match the specific source
                    let filteredImages = Array.from(images).filter(img => img.src.includes('graph-icon'));

                    let zoneCount = 0;

                    try{zoneCount = filteredImages.length;}
                    catch(err){}

                    let calibratedCount = 0;
                    //alert(zoneTables.length) //28
                    const table = zoneTables[i];

                    // Get the innerText of the table (text content without HTML tags)
                    const tableText = table.innerText;
                    // Count occurrences of calibrated
                    const occurrences = tableText.split("✓").length - 1;

                    // Add the occurrences to the total count
                    calibratedCount += occurrences;
                    //console.log("Zone: " + i);
                    //console.log("Calibrated: " + calibratedCount);

                    //let zoneName = zoneTables[i].querySelector("tbody > tr:nth-child(1) > td > table > tbody > tr > td.l.zonename.p100 > a:nth-child(9)").textContent;

                    //let zoneTitle = document.createTextNode(zoneName + ' - ' + zoneCount + ' Sensors, ' + calibratedCount + ' Calibrated. ' + (zoneCount - calibratedCount) + ' left.');

                    zoneTables[i].style = "white-space:nowrap";
                    zoneTables[i].style.fontSize = '17px';
                    //zoneTables[i].style.fontWeight = 'bold';

                    const title = zoneTables[i].querySelector(".zonename a:last-of-type");

                    let count = document.createElement("span");
                    count.textContent = ` - ${calibratedCount}/${zoneCount} Calibrated`;
                    count.style.fontWeight = "bold";



                    if((calibratedCount == zoneCount)){
                        title.parentElement.style.backgroundColor = '#9eff7f';
                        //zoneTitle = document.createTextNode(zoneName + ' - ' + zoneCount + ' Sensors, ' + calibratedCount + ' Calibrated. ');
                        count.textContent = ` - ${calibratedCount}/${zoneCount} Calibrated \u2705`;

                        if(toggleZoneState == "ON"){
                        //console.log("removing");
                        //zoneTables[i].children[0].style.display = "none";
                        const tbody = zoneTables[i].querySelector("tbody");
                            if (tbody) {
                                Array.from(tbody.children).slice(1).forEach(row => {
                                    row.style.display = "none";
                                });
                            }
                            /*const collapseLink = table.querySelector("a");    //cant just hide the zones cause has to reload page for each zone
                            if (collapseLink) {
                                collapseLink.click();
                            }*/
                        }
                    }
                    if(zoneCount == 0){
                        count.textContent = "- 0 Active, or Hidden";
                    }
                    title.insertAdjacentElement("afterend", count);
                    //zoneTables[i].children[0].children[0].children[0].children[0].children[0].children[0].insertAdjacentHTML("beforeend", ' <span style="font-weight:bold;">✅</span>'); //adds zone count and calibrated to zone title

                }
            }
        }
    }
})();


async function deleteStoredData(){
    const keys = await GM.listValues();
        for (const key of keys) {
            await GM.deleteValue(key);
        }
        // Update the last cleanup timestamp
        await GM.setValue("lastCleanup", currentDate.getTime());
    console.log("deleting stored calibration values");
    location.reload();

}

})();
